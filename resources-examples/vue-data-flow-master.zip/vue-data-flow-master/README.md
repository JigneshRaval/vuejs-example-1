# Shared state in vue and vuex

A few quick demo apps to illustrate how to share data between components using vuex as well as a simple shared javascript object.

For more info, please [read this article](https://benjaminlistwon.com/blog/shared-state-in-vue-and-vuex).


