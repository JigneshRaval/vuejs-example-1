# A Vuex simple example

```
$ git clone https://github.com/pbelyaev/vuex-simple-example.git
$ cd easy-vuex
$ npm install
$ npm run build
$ npm run dev
```
