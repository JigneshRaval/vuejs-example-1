export function increment({ dispatch }) {
    dispatch('INCREMENT_VALUE');
}